package com.example.newsapp.ui

import android.os.Bundle
import androidx.preference.PreferenceFragmentCompat
import com.example.newsapp.R // Your R file

class SettingsFragment : PreferenceFragmentCompat() {
    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(R.xml.preferences, rootKey)
    }
}