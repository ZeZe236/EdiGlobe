package com.example.newsapp.ui

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.newsapp.databinding.ActivityMainBinding
import com.example.newsapp.model.Article
import com.example.newsapp.R

class MainActivity : AppCompatActivity(), NewsArticleListener {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: MainViewModel by viewModels()
    private lateinit var newsAdapter: NewsAdapter

    companion object {
        const val EXTRA_ARTICLE_URL = "article_url"
        const val EXTRA_ARTICLE_TITLE = "article_title"
        const val EXTRA_ARTICLE_CONTENT = "article_content"
        const val EXTRA_ARTICLE_IMAGE_URL = "article_image_url"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)
        binding.lifecycleOwner = this
        binding.viewModel = viewModel

        setupRecyclerView()
        observeViewModel()
    }

    private fun setupRecyclerView() {
        newsAdapter = NewsAdapter(this)
        binding.newsRecyclerView.apply {
            adapter = newsAdapter
            layoutManager = LinearLayoutManager(this@MainActivity)
        }
    }

    private fun observeViewModel() {
        viewModel.articles.observe(this) { articles ->
            newsAdapter.submitList(articles)
        }
    }

    override fun onClick(article: Article) {
        val intent = Intent(this, NewsDetailActivity::class.java).apply {
            putExtra(EXTRA_ARTICLE_URL, article.url)
            putExtra(EXTRA_ARTICLE_TITLE, article.title)
            putExtra(EXTRA_ARTICLE_CONTENT, article.content)
            putExtra(EXTRA_ARTICLE_IMAGE_URL, article.urlToImage)
        }
        startActivity(intent)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_settings -> {
                startActivity(Intent(this, SettingsActivity::class.java))
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}