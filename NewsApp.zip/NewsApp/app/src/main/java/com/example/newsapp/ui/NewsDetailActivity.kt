package com.example.newsapp.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.ui.layout.layout
import androidx.databinding.DataBindingUtil
import com.example.newsapp.databinding.ActivityNewsDetailBinding // Generated Data Binding class
import com.example.newsapp.R


class NewsDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityNewsDetailBinding
    private var articleUrl: String? = null

    companion object {
        const val EXTRA_ARTICLE_URL = "extra_article_url"
        const val EXTRA_ARTICLE_TITLE = "extra_article_title"
        const val EXTRA_ARTICLE_CONTENT = "extra_article_content"
        const val EXTRA_ARTICLE_IMAGE_URL = "extra_article_image_url"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_news_detail)
        binding.lifecycleOwner = this // Important for Data Binding

        val title = intent.getStringExtra(EXTRA_ARTICLE_TITLE)
        val content = intent.getStringExtra(EXTRA_ARTICLE_CONTENT)
        val imageUrl = intent.getStringExtra(EXTRA_ARTICLE_IMAGE_URL)
        articleUrl = intent.getStringExtra(EXTRA_ARTICLE_URL)


        binding.articleTitle = title
        binding.articleContent = content ?: "No content available." // Handle null content
        binding.articleImageUrl = imageUrl

        supportActionBar?.title = title ?: "News Details"
        supportActionBar?.setDisplayHomeAsUpEnabled(true) // Add back button

        binding.openInBrowserButton.setOnClickListener {
            articleUrl?.let { url ->
                val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                startActivity(browserIntent)
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}