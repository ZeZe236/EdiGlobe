package com.example.newsapp.ui

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.newsapp.model.Article
import kotlinx.coroutines.launch
import android.util.Log
import com.example.newsapp.network.RetrofitInstance

class MainViewModel : ViewModel() {
    private val _articles = MutableLiveData<List<Article>>()
    val articles: LiveData<List<Article>> = _articles

    private val _isLoading = MutableLiveData<Boolean>(false)
    val isLoading: LiveData<Boolean> = _isLoading

    private val _errorMessage = MutableLiveData<String?>()
    val errorMessage: LiveData<String?> = _errorMessage

    init {
        fetchNews()
    }

    fun fetchNews() {
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            try {
                val response = RetrofitInstance.api.getTopHeadlines()
                if (response.isSuccessful) {
                    _articles.value = response.body()?.articles ?: emptyList()
                } else {
                    val errorBody = response.errorBody()?.string() ?: "No error body"
                    val errorMsg = "API Error: ${response.code()} ${response.message()}\nDetails: $errorBody"
                    _errorMessage.value = errorMsg
                    Log.e("MainViewModel", errorMsg)
                }
            } catch (e: Exception) {
                val errorMsg = "Exception: ${e.message}"
                _errorMessage.value = errorMsg
                Log.e("MainViewModel", errorMsg, e)
            } finally {
                _isLoading.value = false
            }
        }
    }
}