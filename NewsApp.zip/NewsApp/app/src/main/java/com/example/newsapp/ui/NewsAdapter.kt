package com.example.newsapp.ui

import android.preference.PreferenceManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.newsapp.model.Article
import com.example.newsapp.databinding.ItemNewsArticleBinding // Generated Data Binding class

class NewsAdapter(private val clickListener: NewsArticleListener) :
    ListAdapter<Article, NewsAdapter.ArticleViewHolder>(ArticleDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ArticleViewHolder {
        return ArticleViewHolder.from(parent)
    }

    override fun onBindViewHolder(holder: ArticleViewHolder, position: Int) {
        val article = getItem(position)
        holder.bind(article, clickListener)
    }

    class ArticleViewHolder private constructor(private val binding: ItemNewsArticleBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(article: Article, clickListener: NewsArticleListener) {
            fun bind(article: Article, clickListener: NewsArticleListener) {
                binding.article = article
                binding.clickListener = clickListener

                // Access SharedPreferences
                val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(binding.root.context)
                val showDescription = sharedPreferences.getBoolean("show_description_pref", true)
                val showSource = sharedPreferences.getBoolean("show_source_pref", true)

                // Example: Assuming you have a description TextView in your item layout
                // binding.articleDescriptionTextView.visibility = if (showDescription) View.VISIBLE else View.GONE
                binding.articleSourceTextView.visibility = if (showSource) View.VISIBLE else View.GONE
                // Add similar logic for other customizable elements

                binding.executePendingBindings()
            }
        }

        companion object {
            fun from(parent: ViewGroup): ArticleViewHolder {
                val layoutInflater = LayoutInflater.from(parent.context)
                val binding = ItemNewsArticleBinding.inflate(layoutInflater, parent, false)
                return ArticleViewHolder(binding)
            }
        }
    }
}

class ArticleDiffCallback : DiffUtil.ItemCallback<Article>() {
    override fun areItemsTheSame(oldItem: Article, newItem: Article): Boolean {
        return oldItem.url == newItem.url // Use a unique identifier
    }

    override fun areContentsTheSame(oldItem: Article, newItem: Article): Boolean {
        return oldItem == newItem
    }
}