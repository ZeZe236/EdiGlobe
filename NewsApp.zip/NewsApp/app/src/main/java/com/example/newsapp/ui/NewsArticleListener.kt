package com.example.newsapp.ui // Moved to ui package as per architecture

import com.example.newsapp.model.Article

interface NewsArticleListener {
    fun onClick(article: Article)
}