package com.example.newsapp.util

import android.widget.ImageView
import androidx.compose.ui.semantics.error
import androidx.databinding.BindingAdapter
import com.bumptech.glide.Glide // Or Picasso
import com.example.newsapp.R


@BindingAdapter("imageUrl")
fun loadImage(view: ImageView, url: String?) {
    if (!url.isNullOrEmpty()) {
        Glide.with(view.context)
            .load(url)
            .placeholder(R.drawable.ic_launcher_background) // Add a placeholder drawable
            .error(R.drawable.ic_launcher_background) // Add an error drawable
            .into(view)
    } else {
        // Optionally, set a default image or hide the ImageView
        view.setImageResource(R.drawable.ic_launcher_background)
    }
}