package com.example.newsapp.network

import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query
import com.example.newsapp.model.NewsResponse

interface NewsApiService {
    @GET("news") // Or your desired endpoint
    suspend fun getTopHeadlines(
        @Query("category") category: String = "general", // Example parameter
        //@Query("apiKey") apiKey: String
    ): Response<NewsResponse> // Use Response for error handling

    // You can add more endpoints here, e.g., for searching news
    // @GET("v2/everything")
    // suspend fun searchNews(
    //     @Query("q") query: String,
    //     @Query("apiKey") apiKey: String
    // ): Response<NewsResponse>
}
