plugins {
    // Apply the Android Gradle plugin
    id("com.android.application") version "8.1.4" apply false
    // Apply the Kotlin Android plugin
    id("org.jetbrains.kotlin.android") version "1.9.22" apply false
    // Apply the Kotlin annotation processing plugin (for Room)
    id("org.jetbrains.kotlin.kapt") version "1.9.22" apply false
}

tasks.register("clean", Delete::class) {
    delete(rootProject.buildDir)
}