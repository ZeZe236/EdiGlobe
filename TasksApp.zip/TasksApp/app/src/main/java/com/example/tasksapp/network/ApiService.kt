package com.example.tasksapp.network

import com.example.tasksapp.data.Task
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Body

interface ApiService {
    @GET("todos")
    suspend fun getTasks(): List<Task>

    @POST("todos")
    suspend fun createTask(@Body task: Task): Task
}