package com.example.tasksapp.repository

import com.example.tasksapp.data.Task
import com.example.tasksapp.data.TaskDao
import com.example.tasksapp.network.ApiService
import kotlinx.coroutines.flow.Flow

class TaskRepository(private val taskDao: TaskDao, private val apiService: ApiService) {
    val allTasks: Flow<List<Task>> = taskDao.getAllTasks()

    suspend fun insert(task: Task) {
        taskDao.insert(task)
        apiService.createTask(task) // Sync with remote
    }

    suspend fun update(task: Task) {
        taskDao.update(task)
    }

    suspend fun delete(task: Task) {
        taskDao.delete(task)
    }

    suspend fun syncTasks() {
        val remoteTasks = apiService.getTasks()
        remoteTasks.forEach { taskDao.insert(it) }
    }
}