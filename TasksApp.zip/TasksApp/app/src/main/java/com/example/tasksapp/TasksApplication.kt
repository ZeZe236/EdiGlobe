package com.example.tasksapp

import android.app.Application
import com.example.tasksapp.data.AppDatabase
import com.example.tasksapp.network.RetrofitClient
import com.example.tasksapp.repository.TaskRepository

class TasksApplication : Application() {
    val repository by lazy {
        TaskRepository(AppDatabase.getDatabase(this).taskDao(), RetrofitClient.apiService)
    }
}