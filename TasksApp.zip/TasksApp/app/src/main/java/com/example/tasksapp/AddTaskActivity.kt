package com.example.tasksapp

import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.tasksapp.data.Task
import com.example.tasksapp.databinding.ActivityAddTaskBinding
import com.example.tasksapp.viewmodel.TaskViewModel
import com.example.tasksapp.viewmodel.TaskViewModelFactory

class AddTaskActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAddTaskBinding
    private val viewModel: TaskViewModel by viewModels {
        TaskViewModelFactory((application as TasksApplication).repository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddTaskBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.saveButton.setOnClickListener {
            val title = binding.titleEditText.text.toString()
            val description = binding.descriptionEditText.text.toString()
            if (title.isNotEmpty()) {
                viewModel.insert(Task(title = title, description = description, status = "TODO"))
                finish()
            }
        }
    }
}